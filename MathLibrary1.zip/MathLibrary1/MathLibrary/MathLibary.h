#pragma once
#include <iostream>

struct Triangle
{
    int a;
    int b;
    int c;
};

int CalculatePerimeter(Triangle& triangle);
double CalculateArea(Triangle& triangle);
