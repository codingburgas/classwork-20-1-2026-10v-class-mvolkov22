#include "pch.h"
#include "framework.h"
#include "../MathLibrary/MathLibary.h"
#include <iostream>
using namespace std;

int CalculatePerimeter(Triangle& triangle)
{
    return triangle.a + triangle.b + triangle.c;
}

double CalculateArea(Triangle& triangle)
{
    double s = (triangle.a + triangle.b + triangle.c) / 2;
    return sqrt(s * (s - triangle.a) * (s - triangle.b) * (s - triangle.c));
}